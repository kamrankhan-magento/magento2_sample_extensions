# Magento2-ContactFormPlus
<h3>Description/Plan</h3>
<p>Magento 2 module Allows storage of contact forms, as well as adding the ability to "resolve" contacts and provide a note about the resolution.</p><hr/>

<h3>Install instructions</h3>
In progress...
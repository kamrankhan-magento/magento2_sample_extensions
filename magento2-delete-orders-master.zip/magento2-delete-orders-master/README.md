# video of how install without  issues
this video is very simple for how install without any issues in magento 2.04
https://www.youtube.com/watch?v=HrzERj9e0z4

# magento2-delete-orders extension

The last version support mag2.1 and higher:
http://store.ibnab.com/magento-2-extensions/magento2-delete-orders.html

More free extensions for Magento 2 visit:

http://www.ibnab.com/en/resource or http://store.ibnab.com

More courses and tutorials about Magento 2 visit:

http://www.ibnab.com/en/blog/magento-2

# DemoProduct
DemoProduct type for Magento 2

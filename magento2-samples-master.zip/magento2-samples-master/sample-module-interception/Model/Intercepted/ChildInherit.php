<?php
/***
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\SampleInterception\Model\Intercepted;

/**
 * This empty class shows that a plugin registered on a parent will be activated on the children as well.
 */
class ChildInherit extends \Magento\SampleInterception\Model\Intercepted
{
}

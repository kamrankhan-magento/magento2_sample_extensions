/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            sampleWebapi:  'Magento_SampleWebapiClient/js/web-api-client'
        }
    }
};

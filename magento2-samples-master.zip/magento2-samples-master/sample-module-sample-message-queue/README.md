## Synopsis

An extension to demonstrate sending and processing of synchronous/asynchronous queue messages.

## Motivation

This is one of a collection of examples to demonstrate the features of Magento 2.  The intent is to learn by example, following our best practices for developing a modular site using Magento 2.

## Contributors

Magento Core team

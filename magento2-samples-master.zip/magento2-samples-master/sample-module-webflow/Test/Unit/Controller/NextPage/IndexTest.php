<?php
/***
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\SampleWebFlow\Test\Unit\Controller\NextPage;

class IndexTest extends \Magento\SampleWebFlow\Test\Unit\Controller\AbstractWebflowControllerTest
{
    public function setUp()
    {
        $this->className = 'Magento\SampleWebFlow\Controller\NextPage\Index';
        parent::setUp();
    }
}
# magento2-blog
A stupid little module to play around with Magento 2.0

Right now, this has some basic System Config, a controller, a block and a template. Stole most everything from Magento/Cms

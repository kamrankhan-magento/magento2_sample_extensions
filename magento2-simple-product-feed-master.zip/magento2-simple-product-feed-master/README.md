# magento2-simple-product-feed
A simple Magento 2 product feed example

The goal was to create a simple product feed in order to explore Magento 2.

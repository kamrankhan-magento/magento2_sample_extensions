Instructions.

## Installation

This module is intended to be installed using composer.  After including this component and enabling it, you can verify it is installed by going the backend at:

STORES -> Configuration -> ADVANCED/Advanced ->  Disable Modules Output

Once there check that the module name shows up in the list to confirm that it was installed correctly.

##TODO: add webapi.xml
##TODO: add persistence layer
##TODO: review config file

##TODO: load order info from model

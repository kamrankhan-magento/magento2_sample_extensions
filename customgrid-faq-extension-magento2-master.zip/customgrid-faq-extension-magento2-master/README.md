# Customgrid
This includes a module which can submit form data from frontend form and display as grid in Magento2.

Basically, this is a FAQ extension developed in Magento2 which takes entries from frontend and display it as grid in Admin panel.

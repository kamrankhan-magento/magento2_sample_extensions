# magento2-compared-product
new Magento 2 extension from www.ibnab.com for  showing all product in compare for specific customer inside backend
Custom  tab in customer view
Custom grid
More article and extensions Magento 2 visit  www.ibnab.com/en/blog/magento-2 or http://store.ibnab.com


More Free Magento2 Extensions :
http://www.ibnab.com/en/resource
